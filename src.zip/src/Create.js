import {Form} from "react-bootstrap";
import React, {  useState } from "react";


const Create=()=>{
    [input,setInput]=useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        
        
        
    
        fetch('https://api.up2tom.com/v3/models', {
          method: 'POST',
          headers: {
            Authorization: "Token 9307bfd5fa011428ff198bb37547f979",
            "Content-Type": "application/vnd.api+json",
          },
          body: JSON.stringify({input})
        }).then(res => res.json())
        .then(json => setInput(json.input))
      }

      return(
        <Form onSubmit={handleSubmit}>
        <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Drink Choice?<i class="fas fa-chair-office    "></i></Form.Label>
       <Form.Control type="text" value={input} onChange={(e) => setInput(e.target.value)} placeholder="Enter Preference" />
       <Form.Text className="text-muted">
         Please enter your preferred beverage.
       </Form.Text>
     </Form.Group>
   
        </Form>
      )
}
export default Create;