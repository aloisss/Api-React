//import fetchToCurl from 'fetch-to-curl';
import React, { useEffect, useState } from "react";
import Items from './Items';
import {Form} from "react-bootstrap";
import Create from './Create';

const App = () => {
  const url = "https://api.up2tom.com/v3/models";

  const [data,setData] = useState([]);


  

  useEffect(() => {
    fetch(url, {
      headers: {
        Authorization: "Token 9307bfd5fa011428ff198bb37547f979",
        "Content-Type": "application/vnd.api+json",
      },
    })
      .then((response) => response.json())      
      .then((json) => setData(json))
    
  }, []);
  
  return(
    <>
    <div>
      {Object.keys(data).map((key) => {
         return (
           <div key={key}>
              
              {data[key].map((dataItem) => {
                if(dataItem.id==="58d3bcf97c6b1644db73ad12"){
                  return (
                    <Items id={dataItem.id}
                    name={ dataItem.attributes.name}/>
                   )
                }
               
               })}
           </div>
         )
       })}
     </div>

     <Create/>
  
    </>
    
  )
  
};

export default App;
